import streamlit as st
import pandas as pd
import joblib

st.title("🎓 Student Performance Prediction App")
st.write("Enter the details below to predict the student's final score.")

model = joblib.load("model.pkl")

hours = st.number_input("Hours Studied", 0, 15, 5)
attendance = st.number_input("Attendance (%)", 0, 100, 75)
assignments = st.number_input("Assignments Completed", 0, 10, 5)
past = st.number_input("Past Score", 0, 100, 60)

if st.button("Predict Score"):
    data = pd.DataFrame({
        "hours_studied": [hours],
        "attendance": [attendance],
        "assignments_completed": [assignments],
        "past_scores": [past]
    })
    result = model.predict(data)[0]
    st.success(f"Predicted Final Score: {result:.2f}")
